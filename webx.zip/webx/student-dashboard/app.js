var app = angular.module("studentApp", ["ngRoute"]);

app.config(function($routeProvider) {
  $routeProvider
    .when("/", {
      templateUrl: "views/dashboard.html",
      controller: "dashboardController"
    })
    .when("/students", {
      templateUrl: "views/students.html",
      controller: "studentController"
    })
    .otherwise({
      redirectTo: "/"
    });
});
