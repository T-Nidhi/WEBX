app.controller("dashboardController", function($scope) {
  $scope.message = "Welcome to the Student Dashboard!";
});
