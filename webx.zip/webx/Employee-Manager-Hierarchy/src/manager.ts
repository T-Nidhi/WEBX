import { Employee } from './employee';

export class Manager extends Employee {
    public department: string;

    constructor(name: string, age: number, position: string, department: string) {
        super(name, age, position);
        this.department = department;
    }

    displayDetails(): string {
        return `${super.displayDetails()}, Department: ${this.department}`;
    }
}