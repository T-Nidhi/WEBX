export interface IEmployee {
    name: string;
    age: number;
    position: string;
    displayDetails(): string;
}