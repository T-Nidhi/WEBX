// Exporting the classes
export class Employee {
    constructor(public name: string, public position: string) {}
}

export class Manager extends Employee {
    constructor(name: string, position: string, public department: string) {
        super(name, position);
    }
}

// Function to render employee data
export function renderEmployees() {
    const employeeDiv = document.getElementById('employeeDetails');
    if (employeeDiv) {
        employeeDiv.innerHTML = 'Employees rendered!';
    }
}

// Function to render manager data
export function renderManagers() {
    const managerDiv = document.getElementById('managerDetails');
    if (managerDiv) {
        managerDiv.innerHTML = 'Managers rendered!';
    }
}