app.controller('PostController', function($scope, $http) {
  $scope.posts = [];
  $scope.newPost = {};

  // GET request to fetch posts
$scope.posts = [
  { title: "First Day of Class", body: "Students were welcomed and given course materials." },
  { title: "Assignment 1 Released", body: "Submit it by next Monday on the course portal." },
  { title: "Midterm Schedule", body: "Midterm exams will start from next week." },
  { title: "Workshop Announcement", body: "Join the AI workshop this Friday at 10 AM." }
];

  // POST request to add new post
  $scope.addPost = function() {
    $http.post('https://jsonplaceholder.typicode.com/posts', $scope.newPost)
      .then(function(response) {
        alert('Post added (fake API)');
        $scope.posts.unshift(response.data);
        $scope.newPost = {};
      });
  };
});
